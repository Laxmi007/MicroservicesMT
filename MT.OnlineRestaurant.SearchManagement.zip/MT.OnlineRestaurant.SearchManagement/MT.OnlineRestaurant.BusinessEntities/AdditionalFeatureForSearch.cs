﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.BusinessEntities
{
    public class AdditionalFeatureForSearch
    {
        public int rating { get; set; }
        public string cuisine { get; set; }
        public string Menu { get; set; }
    }
}
