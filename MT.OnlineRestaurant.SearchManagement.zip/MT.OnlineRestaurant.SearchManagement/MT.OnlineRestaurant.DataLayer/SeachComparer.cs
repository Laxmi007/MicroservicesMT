﻿using MT.OnlineRestaurant.DataLayer.DataEntity;
using System;
using System.Collections;
using System.Collections.Generic;

namespace MT.OnlineRestaurant.DataLayer
{
    public class SeachComparer : IEqualityComparer<RestaurantSearchDetails>
    {
        public bool Equals(RestaurantSearchDetails x, RestaurantSearchDetails y)
        {
            if (x == y) 
                return true;
            if (x == null || y == null)
                return false;

            return x.restauran_ID == y.restauran_ID;
            throw new NotImplementedException();
        }
            
        public int GetHashCode(RestaurantSearchDetails obj)
        {
            return obj != null ? obj.restauran_ID : 0;
        }
    }
}
