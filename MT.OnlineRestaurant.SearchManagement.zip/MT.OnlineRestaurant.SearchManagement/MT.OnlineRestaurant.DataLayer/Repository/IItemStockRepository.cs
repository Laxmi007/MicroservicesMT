﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer.Repository
{
    public interface IItemStockRepository
    {
        int ItemOutOfStock(int restaurantID, int menuId, long quantity);
        int ItemPriceChanged(int menuId, decimal price);
    }
}
