using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MT.OnlineRestaurant.ReviewUT
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
