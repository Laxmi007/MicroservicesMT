﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer
{
    public class ApplicationString
    {
        public string DB { get; set; }
    }
}
