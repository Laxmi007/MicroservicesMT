﻿namespace MT.OnlineRestaurant.BusinessEntities.Enums
{
    public enum PaymentType
    {
        Cash = 1,
        Debit = 2,
        Credit = 3,
        NoPayment = 4,
    }
}
