﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer.DataEntities
{
    public class CartItemShow
    {
        public int ID { get; set; }
        public List<ItemPrice> ItemDetails { get; set; }
        public decimal TotalPrice { get; set; }
    }
}
