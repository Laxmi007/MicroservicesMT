﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer.DataEntities
{
    public class ItemPrice
    {
        public string ID { get; set; }
        public decimal Price { get; set; }
        public CartItemsEntity Item { get; set; }
    }
}
