﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer.DataEntities
{
    //public class CartItemShow
    //{
    //    public int CartID { get; set; }
    //    public List<ItemDataDetails> ItemName { get; set; }
    //    public decimal TotalPrice { get; set; }
    //}
}
