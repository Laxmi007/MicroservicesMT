﻿using MT.OnlineRestaurant.DataLayer.Context;
using MT.OnlineRestaurant.DataLayer.DataEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer.interfaces
{
    public interface ICartRepository
    {
        IQueryable<TblTableCart> GetCart(int cardID);
        
    }
}
