﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer.Context
{
    public partial class TblTableItem
    {
        //public TblTableItem() 
        //{
        //    TblTableCart = new HashSet<TblTableCart>();
        //}
        public int ID { get; set; }
        public int CartID { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int RataurantID { get; set; }

        public virtual TblTableCart TblTableCart { get; set; }
    }
}
