﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer.Context
{
    public class  TblTableCart
    {
        public TblTableCart()
        {
            TblTableItems = new HashSet<TblTableItem>();         
        }
        public int ID { get; set; }
        public decimal TotalPrice { get; set; }
        public TblTableItem tblTableItem { get; set; }

        
        public virtual ICollection<TblTableItem> TblTableItems { get; internal set; }
    }
}
