﻿using MT.OnlineRestaurant.DataLayer.Context;
using MT.OnlineRestaurant.DataLayer.DataEntities;
using MT.OnlineRestaurant.DataLayer.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer
{
    public class CartRepository: ICartRepository
    {
        private readonly OrderManagementContext db;
        public CartRepository(OrderManagementContext connection)
        {
            db = connection;
        }

        //public IQueryable<CartItemDataShow> GetCart(int cartId)//, int customerId, int restaurantId)
        //{

        //    List<CartItemDataShow> cartData = new List<CartItemDataShow>();
        //    try
        //    {
        //        return cartData.AsQueryable();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //}


        IQueryable<TblTableCart> ICartRepository.GetCart(int cardID)
        {
               // IQueryable<CartItemShow> cartData = new IQueryable<CartItemShow>();
            try
            {
                return db.TblTableCart.AsQueryable();
            }
            catch (Exception ex)
            {
                throw ex;
            }

           }
    }
}
