﻿using MT.OnlineRestaurant.BusinessEntities;
using MT.OnlineRestaurant.BusinessLayer.interfaces;
using MT.OnlineRestaurant.DataLayer.Context;
using MT.OnlineRestaurant.DataLayer.DataEntities;
using MT.OnlineRestaurant.DataLayer.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MT.OnlineRestaurant.BusinessLayer
{
    public class CartBusiness : ICartBusiness
    {

        ICartRepository cartRepository;
       // private readonly string connectionstring;

        public CartBusiness(ICartRepository _cartRepository)
        {
            cartRepository = _cartRepository;
        }
        public IQueryable<TblTableCart> GetCart(int cartId)
        {
            //IQueryable<BusinessEntities.CartItemShow> cartItemShows=null; // = new BusinessEntities.CartItemShow();
            try
            {
                return cartRepository.GetCart(cartId);

                //IQueryable<BusinessEntities.CartItemShow> cartItemShows;

                //TblTableCart tblTableCart = new TblTableCart();
               // return cartRepository.GetCart(cartId);
                
                //BusinessEntities.CartItemShow cart_Information = new BusinessEntities.CartItemShow
                //{
                //    CartID=tblTableCart.CartID,
                //    TotalPrice=tblTableCart.TotalPrice,
                //    // ItemName=tblTableCart.TblTableItems                   
                //};
                ////cartItemShows.Add(cart_Information);    

                //return cartItemShows.AsQueryable();
                  
            }
            catch (Exception ex) { throw ex; }

            
        }

       
    }
}
