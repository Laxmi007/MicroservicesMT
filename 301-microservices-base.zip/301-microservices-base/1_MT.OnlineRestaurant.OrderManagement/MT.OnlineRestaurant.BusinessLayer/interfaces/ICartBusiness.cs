﻿using MT.OnlineRestaurant.BusinessEntities;
using MT.OnlineRestaurant.DataLayer.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MT.OnlineRestaurant.BusinessLayer.interfaces
{
    public interface ICartBusiness
    {
        IQueryable<TblTableCart> GetCart(int cartId);
        
        //List<CartDetails> UpdateCart(int cartId, int customerId, int restaurantId);
        //List<CartDetails> AddToCart(int cartId, int customerId, int restaurantId);
    }
}
