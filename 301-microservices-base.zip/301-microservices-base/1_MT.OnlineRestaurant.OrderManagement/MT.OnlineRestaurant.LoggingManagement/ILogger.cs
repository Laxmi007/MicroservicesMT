﻿namespace LoggingManagement
{
    public interface ILogger
    {
         void LogMessage(string logmessage);
    }
}
