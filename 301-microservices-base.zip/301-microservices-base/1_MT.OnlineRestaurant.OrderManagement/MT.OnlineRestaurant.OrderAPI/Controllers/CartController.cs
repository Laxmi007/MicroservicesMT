﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MT.OnlineRestaurant.BusinessEntities;
using MT.OnlineRestaurant.BusinessLayer.interfaces;

namespace MT.OnlineRestaurant.OrderAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly ICartBusiness business_Repo;
        public CartController(ICartBusiness _bussiness_Repo)
        {
            business_Repo = _bussiness_Repo;
        }

        //[HttpGet]
        //[Route("api/GetCartItems")]
        //public IActionResult GetCartItems()
        //{
        //    //if (Request.Headers.ContainsKey("CustomerId"))
        //    //{
        //    //    var userId = HttpContext.Request.Headers["CustomerId"].ToString();
        //    //}
        //    //var result = _placeCartActions.GetCartDetails(customerId);
        //    //if (result.Any())
        //    //{
        //    //    return Ok(result.ToList());
        //    //}
        //    //return BadRequest("Failed to get the reports");
        //    return Ok();
        //}
        [HttpGet]
        [Route("api/CartDetails")]
        public IActionResult GetCart(int cartId) //,int customerId,int restaurantId)
        {

            // var cartInformation = business_Repo.GetCart(cartId); //, customerId, restaurantId);
            // return Ok(cartInformation);
            return Ok();
        }

        [HttpPost]
        [Route("api/AddItem")]
        public IActionResult AddToCart()
        {
            return this.Ok();
        }

        [HttpPost]
        [Route("api/UpdateItem")]
        public IActionResult UpdateCart()
        {

            return this.Ok();
        }

    }
}