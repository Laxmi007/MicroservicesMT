﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.BusinessEntities.Enums
{
    public enum Status
    {
        Initiated = 1,
        Processing = 2,
        Success = 3,
        Failure = 4
    }
}
