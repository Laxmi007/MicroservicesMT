﻿#region References

#endregion

#region NamespaceDefinition
namespace MT.OnlineRestaurant.BusinessEntities
{
    #region Class Definition
    /// <summary>
    /// Holds the properties for the order status
    /// </summary>
    public class OrderStatus
    {
        public int Id { get; set; }

        public string Status { get; set; }
    }
    #endregion
}
#endregion
