﻿using System;

namespace MessageManagement
{
    public class Class1
    {
    }
}
