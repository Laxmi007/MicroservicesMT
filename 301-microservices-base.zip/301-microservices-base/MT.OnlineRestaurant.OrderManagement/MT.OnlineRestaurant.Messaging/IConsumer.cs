﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.Messaging
{
    public interface IConsumer
    {
        void RegisterOnMessageHandlerAndReceiveMessages();

    }
}
