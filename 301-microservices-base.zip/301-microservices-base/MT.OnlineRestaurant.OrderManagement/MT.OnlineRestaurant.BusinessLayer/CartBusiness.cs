﻿using MT.OnlineRestaurant.BusinessEntities;
using MT.OnlineRestaurant.BusinessLayer.interfaces;
using MT.OnlineRestaurant.DataLayer.Context;
using MT.OnlineRestaurant.DataLayer.interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.BusinessLayer
{
    public class CartBusiness : ICartBusiness
    {
        ICartRepository cartRepository;

        private readonly string connectionstring;
        public CartBusiness( ICartRepository _cartRepository)
        {
            cartRepository = _cartRepository;
        }

        public CartEntity GetCartDetail(int cartID)
        {
            try
            {
                TblTableCart cart = new TblTableCart();
                cart = cartRepository.GetCartDetails(cartID);

                CartEntity cart_Information = new CartEntity()
                {
                    ID = cart.ID,
                    RastaurantId = cart.RastaurantId,
                    MenuId = cart.MenuId,
                    Price = cart.Price,
                    Quantity = cart.Quantity,
                    CostomerId = cart.CostomerId
                };

                return cart_Information;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool AddItem(CartEntity cartEntity)
        {
            bool status;
            try
            {
                return status = cartRepository.AddItem(cartEntity);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool UpdateItem(CartEntity cartEntity)
        {
            bool status;
            try
            {
                return status = cartRepository.UpdateItem(cartEntity);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool DeleteItemInCart(int cartID, int itemID)
        {
            bool status;
            try
            {
                return status = cartRepository.DeleteItem(cartID, itemID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool DeleteCart(int cartID)
        {
            bool status;
            try
            {
                return status = cartRepository.DeleteCart(cartID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
