﻿using MT.OnlineRestaurant.BusinessEntities;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.BusinessLayer.interfaces
{
    public interface ICartBusiness
    {
        CartEntity GetCartDetail(int cartID);
        bool AddItem(CartEntity cartEntity);
        bool UpdateItem(CartEntity cartEntity);
        bool DeleteCart(int cartID);
        bool DeleteItemInCart(int cartID, int itemID);
    }
}
