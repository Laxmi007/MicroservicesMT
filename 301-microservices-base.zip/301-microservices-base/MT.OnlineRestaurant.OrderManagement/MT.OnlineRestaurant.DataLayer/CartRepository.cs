﻿using MT.OnlineRestaurant.DataLayer.Context;
using MT.OnlineRestaurant.DataLayer.interfaces;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using MT.OnlineRestaurant.BusinessEntities;

namespace MT.OnlineRestaurant.DataLayer
{
    public class CartRepository : ICartRepository
    {
        private readonly OrderManagementContext db;
        public CartRepository(OrderManagementContext connection)
        {
            db = connection;
        }
        
       public bool DeleteCart(int cartID)
        {
            bool status = CartDelete(cartID);
            return status;
        }
        public bool DeleteItem(int cartID, int itemID)
        {
            bool status = ItemDelete(cartID,itemID);
            return status;
        }
        public bool UpdateItem(CartEntity cartEntity)
        {
            bool status = ItemUpdate(cartEntity);
            return status;
        }
        public bool AddItem(CartEntity cartEntity)
        {
            bool status = UpdateCart(cartEntity);
            return status;
        }

        public TblTableCart GetCartDetails(int cartID)
        {
            TblTableCart tableCart = new TblTableCart();
            try
            {
                if (db != null)
                {
                    tableCart = (from cart in db.TblTableCart
                                 where cart.ID == cartID
                                 select new TblTableCart
                                 {
                                     ID = cart.ID,
                                     RastaurantId = cart.RastaurantId,
                                     MenuId = cart.MenuId,
                                     Price = cart.Price,
                                     Quantity = cart.Quantity,
                                     CostomerId = cart.CostomerId
                                 }).FirstOrDefault();
                }
                return tableCart;
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }


        #region private methods
        private bool CartDelete(int cartID)
        {
            try
            {
                if (db != null)
                {
                    var deleteCart = from cart in db.TblTableCart
                                     where cart.ID == cartID
                                     select cart;

                    //db.TblTableCart.DeleteOnSubmit(cartID);
                    foreach (var id in deleteCart)
                    {
                        db.TblTableCart.Remove(id);
                    }

                    db.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        private bool ItemDelete(int cartID, int itemID)
        {
            try
            {
                if (db != null)
                {
                    var deleteItem= from cart in db.TblTableCart
                                     where cart.ID == cartID && cart.MenuId==itemID
                                     select cart;

                    //db.TblTableCart.DeleteOnSubmit(cartID);
                    foreach (var id in deleteItem)
                    {
                        db.TblTableCart.Remove(id);
                    }

                    db.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;

        }
        private bool ItemUpdate(CartEntity cartEntity)
        {
            try
            {
                if (db != null)
                {
                    var cartItemFilter = (from cart in db.TblTableCart
                                      where cart.ID == cartEntity.ID && cart.MenuId ==cartEntity.MenuId
                                      select cart);

                    foreach (var item in cartItemFilter)
                    {
                        item.RastaurantId = cartEntity.RastaurantId;
                        item.Price = cartEntity.Price;
                        item.Quantity = cartEntity.Quantity;
                        item.CostomerId = cartEntity.CostomerId;
                    }
                    db.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;


        }
        private bool UpdateCart(CartEntity cartEntity)
        { 
            try
            {
                if (db != null)
                {
                    var cartFilter = (from cart in db.TblTableCart
                                        where cart.ID== cartEntity.ID
                                        select cart);

                    foreach (var item in cartFilter)
                    {
                        item.RastaurantId = cartEntity.RastaurantId;
                        item.MenuId = cartEntity.MenuId;
                        item.Price = cartEntity.Price;
                        item.Quantity = cartEntity.Quantity;
                        item.CostomerId = cartEntity.CostomerId;
                    }
                    db.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

      


        #endregion
    }
}
