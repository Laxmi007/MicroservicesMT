﻿using MT.OnlineRestaurant.BusinessEntities;
using MT.OnlineRestaurant.DataLayer.Context;
using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer.interfaces
{
    public interface ICartRepository
    {
        TblTableCart GetCartDetails(int cartID);
        bool AddItem(CartEntity cartEntity);

        bool UpdateItem(CartEntity cartEntity);
        bool DeleteItem(int cartID, int itemID);
        bool DeleteCart(int cartID);
    }
}
