﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MT.OnlineRestaurant.BusinessEntities;
using MT.OnlineRestaurant.BusinessLayer.interfaces;

namespace MT.OnlineRestaurant.OrderAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {

        private readonly ICartBusiness business_Repo;
        public CartController(ICartBusiness _business_Repo)
        {
            business_Repo = _business_Repo;           
        }
        
        [HttpGet]
        [Route("GetCartDetail")]
        public CartEntity GetCartDetail([FromQuery] int CartID)
        {
            CartEntity cartEntity = new CartEntity();
            cartEntity = business_Repo.GetCartDetail(CartID);

            return cartEntity;
        }

        [HttpPost]
        [Route("AddItemToCart")]
        public IActionResult AddItemToCart([FromBody]CartEntity cartEntity)
        {
            if (business_Repo.AddItem(cartEntity))
            {
                return this.Ok("Item Added to cart successfully.");
            }

            return this.StatusCode((int)HttpStatusCode.InternalServerError, string.Empty);
        }

        [HttpPut]
        [Route("UpdateItemToCart")]
        public IActionResult UpdateItemToCart([FromBody]CartEntity cartEntity)
        {
            if (business_Repo.UpdateItem(cartEntity))
            {
                return this.Ok("Item Updated to cart successfully.");
            }

            return this.StatusCode((int)HttpStatusCode.InternalServerError, string.Empty);
        }
        [HttpDelete]
        [Route("DeleteItemInCart")]
        public IActionResult DeleteItemInCart(int cartID,int itemID)
        {
            if (business_Repo.DeleteItemInCart(cartID, itemID))
            {
                return this.Ok("Item deleted in Cart successfully.");
            }

            return this.StatusCode((int)HttpStatusCode.InternalServerError, string.Empty);
        }
        [HttpDelete]
        [Route("DeleteCart")]
        public IActionResult DeleteCart(int cartID)
        {
            if (business_Repo.DeleteCart(cartID))
            {
                return this.Ok("Cart deleted successfully.");
            }

            return this.StatusCode((int)HttpStatusCode.InternalServerError, string.Empty);
        }
    }
}