﻿using MT.OnlineRestaurant.BusinessReviewEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MT.OnlineRestaurant.BusinessReviewLayer
{
    public interface IReviewBusiness
    {
        IQueryable<ReviewRating> GetResturantDetails(int restaurantID);
        bool UpdateResturantReview(int restaurantID, string comment);
    }
}
