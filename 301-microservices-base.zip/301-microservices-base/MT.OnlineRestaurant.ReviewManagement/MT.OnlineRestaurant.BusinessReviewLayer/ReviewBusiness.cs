﻿using MT.OnlineRestaurant.BusinessReviewEntities;
using MT.OnlineRestaurant.BusinessReviewLayer;
using MT.OnlineRestaurant.DataLayer.DataEnitiy;
using MT.OnlineRestaurant.DataLayer.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MT.OnlineRestaurant.BusinessLayer
{
    public class ReviewBusiness : IReviewBusiness
    {
        IReviewRepository review_Repository;
        

        public ReviewBusiness(IReviewRepository _reviewRepository)
        {
            review_Repository = _reviewRepository;
        }
        public IQueryable<ReviewRating> GetResturantDetails(int restaurantID)
        {

            IQueryable<Rating> ratingDetails;
            List<ReviewRating> reviewRatings = new List<ReviewRating>();
            try
            {
                ratingDetails = review_Repository.GetResturantReviewDetails(restaurantID);

                foreach (var item in ratingDetails)
                {
                    ReviewRating data = new ReviewRating
                    {
                        RestaurantId = item.RestaurantId,
                        rating = item.rating,
                        user_Comments = item.user_Comments,
                        customerId = item.customerId
                    };
                    reviewRatings.Add(data);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return reviewRatings.AsQueryable();

        }

        public bool UpdateResturantReview(int restaurantID, string comment)
        {
            bool status;
            try
            {
                return status = review_Repository.UpdateResturantReviewDetails(restaurantID, comment);
                
            }
            catch (Exception ex)
            {
                throw ex;
            }

            
        }
    }
}
