﻿using MT.OnlineRestaurant.DataLayer.EntityFrameWorkModel;
using MT.OnlineRestaurant.DataLayer.DataEnitiy;
using MT.OnlineRestaurant.DataLayer.Repository.EFContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer.Repository
{
    public class ReviewRepository : IReviewRepository
    {
        private readonly RestaurantReviewManagementContext db;
        public ReviewRepository(RestaurantReviewManagementContext connection)
        {
            db = connection;
        }

        #region Interface Methods
        public IQueryable<Rating> GetResturantReviewDetails(int restaurantID)
        {

            List<Rating> ratingdetails = new List<Rating>();
            try
            {
                if (db != null)
                {
                    var ratingFilter = (from rating in db.TblRating
                                        where rating.TblRestaurantId == restaurantID
                                        orderby rating.Id
                                        select new { TblRating = rating });

                    foreach (var item in ratingFilter)
                    {
                        Rating ratingdetail = new Rating
                        {
                            RestaurantId = restaurantID,
                            rating = item.TblRating.Rating,
                            user_Comments = item.TblRating.Comments,
                            customerId = item.TblRating.TblCustomerId
                        };
                        ratingdetails.Add(ratingdetail);
                    }
                }
                return ratingdetails.AsQueryable();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool UpdateResturantReviewDetails(int restaurantID, string comment)
        {
            bool status = UpdateReview(restaurantID, comment);
            return status;
        }
        #endregion

        #region private methods
        private bool UpdateReview(int restaurantID, string comment)
        {
            try
            {
                if (db != null)
                {
                    var ratingFilter = (from rating in db.TblRating
                                        where rating.TblRestaurantId == restaurantID
                                        select rating);

                    foreach (var item in ratingFilter)
                    {
                        item.Comments = comment;
                    }
                    db.SaveChanges();
                    return true;
                    //var restaurant = db.TblRating.Find(restaurantID);

                    //if (restaurant == null)
                    //    throw new Exception("Resturant is not found");

                    //if (comment != restaurant.Comments)
                    //{
                    //    restaurant.Comments = comment;
                    ////    db.TblRating.Update(restaurant);
                    //    db.SaveChanges();
                    //    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }
        #endregion
    }

}
