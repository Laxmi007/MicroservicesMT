﻿using MT.OnlineRestaurant.DataLayer.DataEnitiy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer.Repository
{
   public  interface IReviewRepository
    {
        IQueryable<Rating> GetResturantReviewDetails(int restaurantID);
        bool UpdateResturantReviewDetails(int restaurantID, string comment);
    }
}
