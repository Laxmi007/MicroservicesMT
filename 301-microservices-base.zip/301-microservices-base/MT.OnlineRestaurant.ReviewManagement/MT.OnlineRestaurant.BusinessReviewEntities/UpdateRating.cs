﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.BusinessEntities
{
    public class UpdateRating
    {
        public int rastaurantID { get; set; }
        public string rating { get; set; }
        public string user_Comment { get; set; }
        public int customerID { get; set; }

    }
}
