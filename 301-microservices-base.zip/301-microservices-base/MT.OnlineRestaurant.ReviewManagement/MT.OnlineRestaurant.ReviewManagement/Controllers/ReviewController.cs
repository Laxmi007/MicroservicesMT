﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MT.OnlineRestaurant.BusinessReviewEntities;
using MT.OnlineRestaurant.BusinessReviewLayer;

namespace MT.OnlineRestaurant.ReviewManagement.Controllers
{
    [Produces("application/json")]
    [Route("api")]
    public class ReviewController : Controller
    {
        private readonly IReviewBusiness business_Repo;
        public ReviewController(IReviewBusiness _bussiness_Repo)
        {
            business_Repo = _bussiness_Repo;
        }
        [HttpGet]
        [Route("ReviewResturant")]
        public IActionResult GetResturantReviewDetail([FromQuery] int restaurantID)
        {
            //IQueryable<RestaurantInformation> restaurantDetails;
            if (restaurantID > 0)
            {
                IQueryable<ReviewRating> resturantInformation;
                resturantInformation = business_Repo.GetResturantDetails(restaurantID);

                if (resturantInformation != null)
                    return this.Ok(resturantInformation);
            }

            return this.StatusCode((int)HttpStatusCode.InternalServerError, string.Empty);
        }

        [HttpPost]
        [Route("UpdateReviewForResturant")]
        public IActionResult UpdateReview([FromQuery] int restaurantID, string comment)
        {
            if (restaurantID > 0 && comment != null)
            {
                if (business_Repo.UpdateResturantReview(restaurantID, comment))
                    return this.Ok();
            }          

            return this.StatusCode((int)HttpStatusCode.InternalServerError, string.Empty);
        }

    }
}