﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.BusinessEntities
{
   public  class StockItems
    {
        public int RestaurantID { get; set; }
        public long Quantity { get; set; }
        public int MenuId { get; set; }
        public decimal Price { get; set; }
        public string Status { get; set; }

    }
}
