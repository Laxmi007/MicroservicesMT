﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using MT.OnlineRestaurant.BusinessEntities;
using MT.OnlineRestaurant.BusinessLayer;

namespace MT.OnlineRestaurant.SearchManagement.Controllers
{
    [Produces("application/json")]
    [Route("api")]
    public class ItemStockController : Controller
    {
        private readonly IRestaurantBusiness business_Repo;
        public ItemStockController (IRestaurantBusiness _business_Repo)
        {
            business_Repo = _business_Repo;
        }

        [HttpPost]
        [Route("ItemOutOfStock")]
        public IActionResult ItemOutOfStock([FromQuery] int restaurantID, int menuId, long quantity)
        {
            int stockItems;
            stockItems = business_Repo.ItemOutOfStock(restaurantID, menuId, quantity);
            if (stockItems > 0)
                return Ok("Available");
            else
                return Ok("Quantity Not Available");

           // return this.StatusCode((int)HttpStatusCode.InternalServerError, "error");
        }

         [HttpPost]
        // Route["ItemPriceChanged"]
         public IActionResult ItemPriceChanged([FromQuery]int menuId, decimal price)
        {
            int priceChangeStatus;
            priceChangeStatus = business_Repo.ItemPriceChanged(menuId, price);

            if (priceChangeStatus > 0)
                return Ok(priceChangeStatus);

            return this.StatusCode((int)HttpStatusCode.InternalServerError, "error");

        }
    }
}