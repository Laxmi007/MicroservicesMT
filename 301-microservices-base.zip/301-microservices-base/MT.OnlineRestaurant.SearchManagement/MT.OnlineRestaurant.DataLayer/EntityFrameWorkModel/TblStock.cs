﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MT.OnlineRestaurant.DataLayer.EntityFrameWorkModel
{
    public class TblStock
    {
        public int RestaurantID { get; set; }
        public int Quantity { get; set; }
    }
}
