﻿using MT.OnlineRestaurant.DataLayer.EntityFrameWorkModel;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace MT.OnlineRestaurant.DataLayer.Repository
{
    public class ItemStockRepository : IItemStockRepository
    {
        private readonly RestaurantManagementContext db;
        public ItemStockRepository(RestaurantManagementContext connection)
        {
            db = connection;
        }
        public int ItemOutOfStock(int restaurantID, int menuId, long quantity)
        {
            try
            {
                if (db != null)
                {

                    TblMenu menuObj = new TblMenu();
                    if (db != null)
                    {
                        menuObj = (from offer in db.TblOffer
                                   join menu in db.TblMenu
                                   on offer.TblMenuId equals menu.Id
                                   join rest in db.TblRestaurantDetails
                                   on offer.TblRestaurantId equals rest.TblRestaurantId
                                   where rest.TblRestaurantId == restaurantID && menu.Id == menuId
                                   & menu.quantity >= quantity
                                   select new TblMenu
                                   {
                                       quantity = menu.quantity
                                   }).FirstOrDefault();
                    }
                    return menuObj.quantity;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


            throw new NotImplementedException();
        }

        public int ItemPriceChanged(int menuId, decimal price)
        {
            throw new NotImplementedException();
        }
    }
}
